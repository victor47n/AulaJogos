﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public delegate Vector3 GraphicFunctions(float x, float z, float t);