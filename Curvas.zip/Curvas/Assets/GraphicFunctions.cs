﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public delegate float GraphicFunctions(float x, float y);