﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Animation : MonoBehaviour
{
    /* Variável para gerenciar o Prefab */
    public Transform ptCube;

    /* Controle de resolução do gráfico */
    [Range(10, 100)]
    public int resolution = 10;

    /* Controle da função a renderizar */
    // [Range(0, 1)]
    // public int Function;
    public FunctionNames fc;

    /* Variável para controlar o conjunto de pontos */
    Transform[] points;


    void Awake()
    {
        float step = 2f / resolution;

        Vector3 scale = Vector3.one * step;
        Vector3 position;

        position.y = 0f;
        position.z = 0f;

        points = new Transform[resolution * resolution];

        for (int cubes = 0, x = 0; cubes < resolution; cubes++, x++)
        {
            Transform point = Instantiate(ptCube);
            position.x = (((cubes + 0.5f) * step) - 1f);
            // position.y = position.x * position.x; // y = x^2;
            point.localPosition = position;
            point.localScale = scale;
            point.SetParent(transform, false);
            points[cubes] = point; /* Guardando os pontos gerados */
        }
        
    }

    private void Update()
    {
        float t = Time.time;
        GraphicFunctions f = functions[(int) fc];
        float step = 2f / resolution;

        for(int c = 0, z = 0; z < resolution; z++)
        {
            float v = ((z + 0.5f) * step) - 1f;

            for(int x = 0; x < resolution; x++, c++)
            {
                float u = ((x + 0.5f) * step) - 1f;
                points[c].localPosition = f(u, v, t);
            }

            //Transform point = points[c];
            //Vector3 position = point.localPosition;
            //// positioon.y = position.x; // y = x reta inclinada
            //// positiony. = position.x * position.x; y = x^2 parábola
            //// position.y = position.x * position.x * position.x; // y = x^3 curva "cobrinha"
            //// position.y = Mathf.Sin(Mathf.PI * (position.x + Time.time)); // y = sen(x) senoidal
            //position.y = f(position.x, t);
            
            //point.localPosition = position;
            
        }
    }

    static GraphicFunctions[] functions = { Sine, MultiSine, Sine2D, MultiSine2D, Whirlwind, Star, LivingBall, Toroid };
    public enum FunctionNames
    {
        Sine,
        MultiSine,
        Sine2D,
        MultiSine2D,
        Whirlwind,
        Star,
        LivingBall,
        Toroid
    }

    /// <summary>
    /// Fun;áo para gerar o gráfic de seno animado
    /// </summary>
    /// <param name="x">Valorda pocicão</param>
    /// <param name="t">Balor do temp</param>
    /// <returns></returns>
    static Vector3 Sine(float x, float z, float t)
    {
        Vector3 p;
        p.x = x;
        p.y = Mathf.Sin(Mathf.PI * (x + 2f * t)) / 2f;
        p.z = z;
        return p;
    }

    /// <summary>
    /// Função para gerar uma combinação de senos animados
    /// </summary>
    /// <param name="x">Valor da posição x</param>
    /// <param name="t">Valor do tempo t</param>
    /// <returns>Retorna a posição Y calculada</returns>
    static Vector3 MultiSine(float x, float z, float t)
    {
        Vector3 p;
        p.x = x;
        p.y = Mathf.Sin(Mathf.PI * (x + t));
        p.y += Mathf.Sin(2f * Mathf.PI * (x + t));
        p.y *= 2f / 3f;
        p.z = z;

        return p;
    }

    static Vector3 Sine2D(float x, float z, float t)
    {
        Vector3 p;

        p.x = x;
        p.y = Mathf.Sin(Mathf.PI * (x + t));
        p.y += Mathf.Sin(Mathf.PI * (z + t));
        p.y *= 0.5f;
        p.z = z;

        return p;
    }

    static Vector3 MultiSine2D(float x, float z, float t)
    {
        Vector3 p;

        p.x = x;
        p.y = 4f * Mathf.Sin(Mathf.PI * (x + z + (t / 2f)));
        p.y += Mathf.Sin(Mathf.PI * (x + t));
        p.y += Mathf.Sin(2f * (Mathf.PI * (z + (2 * t)))) * 0.5f;
        p.y *= 1f / 5.5f;
        p.z = z;

        return p;
    }

    static Vector3 Whirlwind(float x, float z, float t)
    {
        Vector3 p;

        float d = Mathf.Sqrt((x * x) + (z * z));
        p.x = x;
        p.y = Mathf.Sin(Mathf.PI * ((4f * d) - t));
        p.y /= 1f + (10f * d);
        p.z = z;

        return p;
    }

    static Vector3 Star(float x, float z, float t)
    {
        Vector3 p;

        float r = 0.8f + (Mathf.Sin(Mathf.PI * (6f * x) + (2f * z) + t) * 0.2f);
        p.x = r * Mathf.Sin(Mathf.PI * x);
        p.y = z;
        p.z = r * Mathf.Cos(Mathf.PI * x);

        return p;
    }

    static Vector3 LivingBall(float x, float z, float t)
    {
        Vector3 p;

        float r = 0.8f + (Mathf.Sin(Mathf.PI * ((6f * x) + t)) * 0.1f);
        r += Mathf.Sin(Mathf.PI * ((4f * z) + t));
        float s = r * Mathf.Cos(Mathf.PI * (0.5f * z));
        p.x = s * Mathf.Sin(Mathf.PI * x);
        p.y = r * Mathf.Sin(Mathf.PI * (0.5f * z));
        p.z = s * Mathf.Cos(Mathf.PI * x);

        return p;
    }

    static Vector3 Toroid(float x, float z, float t)
    {
        Vector3 p;

        float r1 = 0.65f + (Mathf.Sin(Mathf.PI * ((6f * x) + t)) * 0.1f);
        float r2 = 0.2f + (Mathf.Sin(Mathf.PI * ((4f * x) + t)) * 0.05f);
        float s = (r2 * Mathf.Cos(Mathf.PI * z)) + r1;
        p.x = s * Mathf.Sin(Mathf.PI * x);
        p.y = r2 * Mathf.Sin(Mathf.PI * z);
        p.z = s * Mathf.Cos(Mathf.PI * x);

        return p;
    }
}
